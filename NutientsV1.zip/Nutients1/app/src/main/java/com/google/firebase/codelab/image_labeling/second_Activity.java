package com.google.firebase.codelab.image_labeling;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.theartofdev.edmodo.cropper.CropImage;
import java.io.FileNotFoundException;
import java.io.IOException;

public  class second_Activity extends AppCompatActivity {

    Intent i;
    Button btn;
    ImageView myImg;
    //declare the image Uri
    Bitmap bitmap;
    Uri mImageuri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_);

        myImg = findViewById(R.id.mimageView);
        mImageuri=getIntent().getData();
        setmImageuri();

    }
    //mImageuri = i.getParcelableExtra("imageuri");


    public  void setmImageuri() {
        try {

            //uri to= bitmap covert
            bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), mImageuri);
            myImg.setImageBitmap(bitmap);
            Toast.makeText(this, "inside setimageuri", Toast.LENGTH_SHORT).show();
        } catch (FileNotFoundException e) {
            Toast.makeText(this,"Possible error is:"+e,Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        } catch (Exception e) {
            Toast.makeText(this,"Possible error is:"+e,Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }

    }





}
