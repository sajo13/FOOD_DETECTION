package com.google.firebase.codelab.image_labeling;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.FileNotFoundException;
import java.io.IOException;

public class firstactivity extends AppCompatActivity {

    
    Button btn;
    ImageView myImg;
    //declare the image Uri
    Uri mImageuri;
    Bitmap bitmap;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firstactivity);
        
        //Initialise the views
        btn=findViewById(R.id.mbutton);
        myImg=findViewById(R.id.mimageView);
    }
    //button onclick
    public void  onChooserFile(View v){
       CropImage.activity().start(this);      //after the selection the data passed to first activity
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE){
            CropImage.ActivityResult result=CropImage.getActivityResult(data);


            if(resultCode ==RESULT_OK){
                    mImageuri= result.getUri();

                //Toast.makeText(this,"inside if",Toast.LENGTH_SHORT).show();
                    //intent
                    Intent i=new Intent(this,second_Activity.class);
                    i.setData(mImageuri);
                   // i.putExtra("imageuri",mImageuri);
                    startActivity(i);


                    //bitmap= MediaStore.Images.Media.getBitmap(this.getContentResolver(),mImageuri);
                    //myImg.setImageBitmap(bitmap);
                   // Toast.makeText(this,"inside if",Toast.LENGTH_SHORT).show();
            }
            else if (resultCode== CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE)
            {
                Exception e=result.getError();
                Toast.makeText(this,"Possible error is:"+e,Toast.LENGTH_SHORT).show();
            }

        }
    }
}
